## Objetivo

Se espera que puedas comprender bien los conceptos de componentes y cómo trabaja React.

## Instrucciones

Como en los sprints pasados, tendrás una carpeta con toda la información y paleta de colores.
Además se te proveerá una carpeta con dos archivos .json para trabajar con ellos.

Además en esta ocasión incluimos algunas imágenes de qué resultado debería de tener tu proyecto en cierto día del desafío. La imagen puede servir para que tengas un parámetro de qué tanto debes avanzar o qué tanto has avanzado.
